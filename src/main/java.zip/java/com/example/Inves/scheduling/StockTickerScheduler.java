package com.example.Inves.scheduling;


import com.example.Inves.models.Stock;
import com.example.Inves.models.StockPrice;
import com.example.Inves.persistence.repositories.StockDAORepository;
import com.example.Inves.persistence.repositories.StockPriceDAORepository;
import com.example.Inves.services.StockNotificationService;
import com.example.Inves.services.impl.StockTickerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author Bossowski
 * @version 1.0
 * @email Mbossowski01@gmail.com
 * @date 27/12/2024 - 18:51
 */
@Component
public class StockTickerScheduler {

    @Autowired
    private StockTickerService stockTickerService;

    @Autowired
    private StockDAORepository stockRepository;

    @Autowired
    private StockPriceDAORepository stockPriceRepository;

    @Autowired
    private StockNotificationService stockNotificationService;

    @Scheduled(fixedRate = 60000) // Every minute
    public void fetchStockData() {

        // Fetch the stock data (you can replace this with your logic for fetching data from the API)
        // Assuming you have a list of stocks to process (you can replace this with actual data)
        List<Stock> stocks = stockTickerService.getStockTickers("nasdaq", null, null, null);

        LocalDateTime currentDateTime = LocalDateTime.now().withNano(0);

        // Loop through each stock and upsert it
            for (Stock stock : stocks) {
                Optional<Stock> existingStock = stockRepository.findBySymbol(stock.getSymbol());

                if (existingStock.isPresent()) {
                    // Update existing stock
                    stockRepository.updateStockData(stock.getSymbol(), stock.getLastSale(), stock.getNetChange(),
                            stock.getPctChange(), stock.getVolume());
                } else {
                    // Insert new stock
                    stockRepository.insertStockData(stock.getSymbol(), stock.getCompanyName(), stock.getLastSale(),
                            stock.getNetChange(), stock.getPctChange(), stock.getVolume(), stock.getMarket(),
                            stock.getCountry(), stock.getIndustry(), stock.getSector());
                }


                StockPrice newStockPrice = new StockPrice(stock.getSymbol(), stock.getLastSale(), currentDateTime );
                stockPriceRepository.save(newStockPrice);

                // Powiadomienie klientów
                stockNotificationService.sendStockUpdate(stock);
                stockNotificationService.sendStockPriceUpdate(newStockPrice);
            }
        }

    }