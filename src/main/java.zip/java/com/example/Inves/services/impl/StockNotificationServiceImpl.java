package com.example.Inves.services.impl;

import com.example.Inves.services.StockNotificationService;
import com.example.Inves.models.Stock;
import com.example.Inves.models.StockPrice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

/**
 * @author Bossowski
 * @version 1.0
 * @email Mbossowski01@gmail.com
 * @date 30/12/2024 - 15:53
 */
@Service
public class StockNotificationServiceImpl implements StockNotificationService {

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    public void sendStockUpdate(Stock stock) {
        messagingTemplate.convertAndSend("/topic/stocks", stock);
    }

    public void sendStockPriceUpdate(StockPrice stockPrice) {
        messagingTemplate.convertAndSend("/topic/stockPrices", stockPrice);
    }
}
