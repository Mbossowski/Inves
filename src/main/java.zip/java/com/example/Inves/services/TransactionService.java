package com.example.Inves.services;

/**
 * @author Bossowski
 * @version 1.0
 * @email Mbossowski01@gmail.com
 * @date 29/11/2024 - 11:50
 */
public interface TransactionService {
}
