package com.example.Inves.services;

import com.example.Inves.models.Stock;
import com.example.Inves.models.StockPrice;

/**
 * @author Bossowski
 * @version 1.0
 * @email Mbossowski01@gmail.com
 * @date 30/12/2024 - 15:52
 */
public interface StockNotificationService {

    public void sendStockUpdate(Stock stock);

    public void sendStockPriceUpdate(StockPrice stockPrice);
}
