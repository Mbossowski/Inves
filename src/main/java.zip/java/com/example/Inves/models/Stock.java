package com.example.Inves.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;


import java.math.BigDecimal;
import java.util.*;

/**
 * @author Bossowski
 * @version 1.0
 * @email Mbossowski01@gmail.com
 * @date 28/11/2024 - 12:58
 */
@Data
@Entity
@Builder
@AllArgsConstructor
public class Stock {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    private Long id;

    @Column(unique = true, nullable = false)
    private String symbol;

    private String companyName;
    private Double lastSale;
    private Double netChange;
    private Double pctChange;
    private Integer volume;
    private Double marketCap;
    private String market;
    private String country;
    private String industry;
    private String sector;



    @OneToMany(mappedBy = "stock", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<StockPrice> stockPrices = new HashSet<>();


    // Default constructor
    public Stock() {}


    public Stock(String symbol, String companyName, Double lastSale, Double netChange, Double pctChange, Integer volume, Double marketCap, String market, String country, String industry, String ssector) {
     this.symbol = symbol;
     this.companyName = companyName;
     this.lastSale = lastSale;
     this.netChange = netChange;
     this.pctChange = pctChange;
     this.volume = volume;
     this.marketCap = marketCap;
     this.market = market;
     this.country = country;
     this.industry = industry;
     this.sector = ssector;

    }

    public void addStockPrice(StockPrice stockPrice) {
        stockPrices.add(stockPrice);
        stockPrice.setStock(this);
    }

    public void removeStockPrice(StockPrice stockPrice) {
        stockPrices.remove(stockPrice);
        stockPrice.setStock(null);
    }
}
