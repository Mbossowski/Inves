import React, { useState } from "react";
import "./LoginPopup.css";
import { useUser } from "../../context/UserContext"; // Import the useUser hook

const LoginPopup = ({ closePopup, onLoginSuccess }) => {
  const [usernameInput, setUsernameInput] = useState("");
  const [passwordInput, setPasswordInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(""); // State for error messages
  const { setUserInfo } = useUser(); // Access the setUserInfo function from context

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError(""); // Clear previous errors

    if (!usernameInput || !passwordInput) {
      setError("Both fields are required.");
      setIsLoading(false);
      return;
    }

    try {
      const response = await fetch("http://localhost:8080/api/user/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username: usernameInput, password: passwordInput }),
      });

      if (response.ok) {
        const user = await response.json(); // Ensure backend sends { id, username, ... }
        setUserInfo(user); // Save user info in context and localStorage
        
        onLoginSuccess(user); // Notify parent about successful login
        closePopup(); // Close the login popup
      } else {
        const errorMsg = await response.text(); // Get error message from server
        setError(errorMsg || "Invalid username or password");
      }
    } catch (error) {
      console.error("Login error:", error);
      setError("Error connecting to the server. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="login-popup-overlay" role="dialog" aria-modal="true">
      <div className="login-popup" role="document">
        <h2>Login</h2>
        <form onSubmit={handleLogin}>
          <div className="input-group">
            <label htmlFor="username">Username</label>
            <input
              type="text"
              id="username"
              value={usernameInput}
              onChange={(e) => setUsernameInput(e.target.value)}
              required
              disabled={isLoading}
              aria-invalid={!!error}
              aria-describedby={error ? "error-message" : undefined}
            />
          </div>
          <div className="input-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              required
              disabled={isLoading}
              aria-invalid={!!error}
              aria-describedby={error ? "error-message" : undefined}
            />
          </div>
          {error && (
            <p id="error-message" className="error-message">
              {error}
            </p>
          )}
          <div className="button-group">
            <button type="submit" disabled={isLoading}>
              {isLoading ? "Logging in..." : "Login"}
            </button>
            <button
              type="button"
              onClick={() => {
                setUsernameInput(""); // Clear username
                setPasswordInput(""); // Clear password
                setError(""); // Clear errors
                closePopup();
              }}
              disabled={isLoading}
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginPopup;
