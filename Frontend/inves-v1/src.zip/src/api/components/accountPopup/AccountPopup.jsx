import React, { useState, useEffect } from 'react';
import './AccountPopup.css';

const AccountPopup = ({ closePopup }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');

  // Simulate a function to check if the user is logged in and get the username
  // For now, we are using localStorage as an example. Replace with your actual auth logic
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user')); // Replace with your auth state
    if (user && user.username) {
      setIsLoggedIn(true);
      setUsername(user.username);
    }
  }, []);

  return (
    <div className="account-popup-overlay">
      <div className="account-popup">
        <h2>Account</h2>
        <div className="account-info">
          {isLoggedIn ? (
            <p>Welcome, {username}</p>
          ) : (
            <p>User not logged in</p>
          )}
        </div>
        <div className="button-group">
          <button type="button" onClick={closePopup}>
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default AccountPopup;
