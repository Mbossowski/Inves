import React, { useState, useEffect } from "react";
import "./Sidebar.css";
import StockItem from "./StockItem";
import api from "../../axiosConfig"; // Import the Axios instance

const Sidebar = ({ user, onStockClick, refreshWatchlist }) => {
  const [stocks, setStocks] = useState([]);
  const [watchlist, setWatchlist] = useState([]);
  const [pagination, setPagination] = useState({
    page: 0,
    size: 10,
    totalPages: 0,
    totalElements: 0,
  });
  const [searchQuery, setSearchQuery] = useState(""); // State for search input
  const [isWatchlistActive, setIsWatchlistActive] = useState(false);
  const [pageInput, setPageInput] = useState(""); // State for the page input field

  // Fetch stocks based on searchQuery
  const getStocks = async (searchQuery = "", page = 0, size = 10) => {
    try {
      const response = await api.get(
        `/stock?page=${page}&size=${size}&query=${searchQuery}`
      );
      setStocks(response.data.content);
      setPagination({
        page: response.data.pageable.pageNumber,
        size: response.data.pageable.pageSize,
        totalPages: response.data.totalPages,
        totalElements: response.data.totalElements,
      });
    } catch (err) {
      console.error("Error fetching stocks:", err);
    }
  };

  // Fetch the user's watchlist
  const getWatchlist = async () => {
    if (user) {
      try {
        const response = await api.get(`/watchlist/${user.id}`);
        setWatchlist(response.data);
        
      } catch (err) {
        console.error("Error fetching watchlist:", err);
      }
    }
  };

  // Fetch initial stocks and watchlist
  useEffect(() => {
    getStocks();
  }, []);

  useEffect(() => {
    if (user) {
      getWatchlist();
    }
  }, [user]);

  // Refresh the watchlist whenever a stock is added or when it's toggled
  useEffect(() => {
    if (isWatchlistActive && user) {
      getWatchlist();
    }
  }, [isWatchlistActive, user]);

  useEffect(() => {
    if (!user) {
      setIsWatchlistActive(false);
    }
  }, [user]);

  const handleToggle = (option) => {
    // Only allow toggle if the user is logged in
    if (!user) return;
    setIsWatchlistActive(option === "watchlist");
    setSearchQuery(""); // Reset search query when toggling
  };

  const handlePageChange = (newPage) => {
    if (newPage >= 0 && newPage < pagination.totalPages) {
      setPagination((prevState) => ({
        ...prevState,
        page: newPage,
      }));
      getStocks(searchQuery, newPage, pagination.size);
    }
  };

  const handlePageInputChange = (e) => {
    const value = e.target.value;
    // Ensure input is a number and within the page range
    if (/^\d+$/.test(value) && parseInt(value) <= pagination.totalPages) {
      setPageInput(value);
    }
  };

  const handlePageInputSubmit = () => {
    const pageNum = parseInt(pageInput, 10) - 1; // Convert to 0-based index
    if (pageNum >= 0 && pageNum < pagination.totalPages) {
      handlePageChange(pageNum);
    }
  };

  const displayItems = isWatchlistActive ? watchlist : stocks;

  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <div className="toggle-switch">
          <div
            className={`toggle-option ${!isWatchlistActive ? "active" : ""}`}
            onClick={() => handleToggle("all")}
          >
            Stocks
          </div>
          <div
            className={`toggle-option ${isWatchlistActive ? "active" : ""} ${
              !user ? "disabled" : ""
            }`}
            onClick={() => handleToggle("watchlist")}
          >
            Watchlist
          </div>
        </div>

        {/* Search Bar */}
        {!isWatchlistActive && (
          <input
            type="text"
            placeholder="Search stocks..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="stock-search"
          />
        )}
      </div>
      <div className="stock-list">
        {displayItems.map((item) => (
          <StockItem key={item.symbol} stock={item} onClick={() => onStockClick(item)} />
        ))}
      </div>

      {/* Page Selector */}
      {pagination.totalPages > 1 && (
        <div className="pagination">
          <button
            onClick={() => handlePageChange(pagination.page - 1)}
            disabled={pagination.page === 0}
            className="nav-button"
          >
            &lt; Prev
          </button>

          <button
            onClick={() => handlePageChange(pagination.page + 1)}
            disabled={pagination.page === pagination.totalPages - 1}
            className="nav-button"
          >
            Next &gt;
          </button>
        </div>
      )}
    </div>
  );
};

export default Sidebar;
