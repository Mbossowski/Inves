import React from "react";
import "./Sidebar.css";
import "../home/Home.css"

const StockItem = ({ stock, onClick }) => {
    return (
        <div className="stock-item" onClick={onClick}>
        <div className="stock-item-symbol">
          <span>{stock.symbol}</span>
           <span>     </span>
          <span>{stock.lastSale}$</span>
        </div>
        <div className="stock-item-value">
          <span>{stock.companyName}</span>
        </div>
      </div>
    );
  };
  
  export default StockItem;
