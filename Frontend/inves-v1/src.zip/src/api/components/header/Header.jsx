import React, { useState, useEffect, useRef } from "react";
import "./Header.css";
import LoginPopup from "../loginPopup/LoginPopup";
import { useNavigate } from "react-router-dom";

const Header = ({ onThemeChange, onLogout }) => {
  const [showSettings, setShowSettings] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [showAccountPopup, setShowAccountPopup] = useState(false);
  const [showLoginPopup, setShowLoginPopup] = useState(false);
  const [username, setUsername] = useState("");
  const navigate = useNavigate();

  // Refs for detecting clicks outside popups
  const settingsPopupRef = useRef(null);
  const accountPopupRef = useRef(null);

  useEffect(() => {
    // Load theme only if it's not already set
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme && !isDarkMode) {
      setIsDarkMode(savedTheme === "dark");
      onThemeChange(savedTheme);
    }
  }, [isDarkMode, onThemeChange]);

  useEffect(() => {
    // Load user info once
    const savedUser = localStorage.getItem("user");
    if (savedUser) {
      const user = JSON.parse(savedUser);
      if (user?.username && user.username !== username) {
        setUsername(user.username); // Set username only once if it's not already set
      }
    }
  }, [username]); // Will only run when username is not yet set

  useEffect(() => {
    // Close popups when clicking outside
    const handleClickOutside = (event) => {
      if (
        settingsPopupRef.current &&
        !settingsPopupRef.current.contains(event.target)
      ) {
        setShowSettings(false);
      }
      if (
        accountPopupRef.current &&
        !accountPopupRef.current.contains(event.target)
      ) {
        setShowAccountPopup(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const toggleSettings = () => setShowSettings((prev) => !prev);

  const handleThemeChange = () => {
    const newMode = isDarkMode ? "light" : "dark";
    setIsDarkMode(!isDarkMode);
    onThemeChange(newMode);
    localStorage.setItem("theme", newMode);
  };

  const toggleAccountPopup = () => setShowAccountPopup((prev) => !prev);

  const toggleLoginPopup = () => setShowLoginPopup((prev) => !prev);

  const handleLogout = () => {
    if (window.confirm("Are you sure you want to log out?")) {
      onLogout();
      setUsername("");
      localStorage.removeItem("user"); // Ensure user data is cleared
      navigate("/"); // Redirect to homepage
      setShowAccountPopup(false); // Close the account popup
    }
  };

  return (
    <div className="header">
      <div className="logo">INves</div>
      <div className="header-buttons">
        <button
          className="header-button"
          onClick={toggleSettings}
          aria-expanded={showSettings}
          aria-label="Settings"
        >
          Settings
        </button>
        <button
          className="header-button"
          onClick={toggleAccountPopup}
          aria-expanded={showAccountPopup}
          aria-label="Account"
        >
          Account
        </button>
      </div>

      {showAccountPopup && (
        <div
          className="account-popup"
          ref={accountPopupRef}
          role="dialog"
          aria-hidden={!showAccountPopup}
        >
          <h3>Account</h3>
          {username ? (
            <>
              <p>Welcome, {username}</p>
              <button
                className="account-info-button"
                onClick={() => navigate("/user-info")}
              >
                View Account Info
              </button>
              <button className="logout-button" onClick={handleLogout}>
                Logout
              </button>
            </>
          ) : (
            <p>You are not logged in.</p>
          )}
        </div>
      )}

      {/* Settings Popup */}
      {showSettings && (
        <div
          className="settings-popup"
          ref={settingsPopupRef}
          role="dialog"
          aria-hidden={!showSettings}
        >
          <div className="theme-toggle-container">
            <span>Dark Mode</span>
            <label className="switch">
              <input
                type="checkbox"
                checked={isDarkMode}
                onChange={handleThemeChange}
              />
              <span className="slider"></span>
            </label>
          </div>
        </div>
      )}

      {/* Login Popup */}
      {showLoginPopup && (
        <LoginPopup
          setUsername={setUsername}
          closePopup={toggleLoginPopup}
        />
      )}
    </div>
  );
};

export default Header;
