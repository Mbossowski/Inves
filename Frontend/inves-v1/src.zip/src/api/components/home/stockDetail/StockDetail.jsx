import React, { useState, useEffect } from 'react';
import axios from 'axios';
import StockChart from './StockChart'; 
import './StockDetail.css';

const StockDetails = ({ stock, theme, onBack, refreshWatchlist }) => {
  const [stockPrices, setStockPrices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [shares, setShares] = useState(0);
  const [action, setAction] = useState('buy'); // Default action is 'buy'

  useEffect(() => {
    const fetchStockPrices = async () => {
      try {
        const response = await fetch(`http://localhost:8080/api/stockPrice/${stock.symbol}`);
        if (!response.ok) {
          throw new Error('Failed to fetch stock prices');
        }
        const data = await response.json();
        const formattedData = data.map(item => ({
          date: new Date(item.datetime), // Upewnij się, że `item.date` to prawidłowy format daty
          price: item.lastSale
        }));
        console.log(formattedData);
        setStockPrices(formattedData);
        setLoading(false);
      } catch (error) {
        setError(error.message);
        setLoading(false);
      }
    };

    fetchStockPrices();
  }, [stock.symbol]);

  const handleAddToWatchlist = async (stock) => {
    try {
      const user = JSON.parse(localStorage.getItem("user"));
      const userId = user ? user.id : null;
      
      const stockRequest = {
        symbol: stock.symbol,
        companyName: stock.companyName,
        market: stock.market,
        currency: stock.currency
      };

      await axios.put(`http://localhost:8080/api/watchlist?userId=${userId}`, stockRequest);
      alert(`Added ${stock.symbol} to your Watchlist!`);
      refreshWatchlist(); 
    } catch (error) {
      console.error('Error adding to watchlist:', error);
      alert('There was an error adding the stock to your watchlist.');
    }
  };

  const handleTransaction = () => {
    if (shares <= 0) {
      alert('Please specify a valid number of shares.');
      return;
    }

    const transactionData = {
      symbol: stock.symbol,
      amount: shares,
      action
    };

    console.log(`Executing ${action} of ${shares} shares of ${stock.symbol}`);
    alert(`${action === 'buy' ? 'Bought' : 'Sold'} ${shares} shares of ${stock.symbol}`);
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className={`stock-detail ${theme}`}>
      <div className={`back-button-field ${theme}`}>
        <button className="back-button" onClick={onBack}>&#8592; Back</button>
        <button className="add-to-watchlist" onClick={() => handleAddToWatchlist(stock)}>
          Add to Watchlist
        </button>
      </div>

      <div className="stock-header">
        <h2>{stock.symbol}</h2>
        <p className="stock-market-info">
          {stock.companyName} - {stock.market} - {stock.currency}
        </p>
      </div>

      
        <div className={`stock-graph ${theme}`}>
          <StockChart data={stockPrices} />
        </div>
      

      <div className="stock-transaction-section">
        <div className="transaction-section">
          <h3>Transactions</h3>
          <div className="transaction-fields">
            <input
              type="number"
              value={shares}
              onChange={(e) => setShares(Number(e.target.value))}
              min="1"
              placeholder="Enter number of shares"
            />
            <div className="action-buttons">
              <button onClick={() => setAction('buy')} className={action === 'buy' ? 'active' : ''}>
                Buy
              </button>
              <button onClick={() => setAction('sell')} className={action === 'sell' ? 'active' : ''}>
                Sell
              </button>
            </div>
            <button className="transaction-button" onClick={handleTransaction}>
              {action === 'buy' ? 'Buy Shares' : 'Sell Shares'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StockDetails;
