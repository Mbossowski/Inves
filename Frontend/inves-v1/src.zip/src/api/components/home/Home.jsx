import React, { useState, useEffect } from "react";
import Sidebar from "../sidebar/Sidebar";
import Header from "../header/Header";
import LoginPopup from "../loginPopup/LoginPopup";
import RegisterPopup from "../registerPopup/RegisterPopup";
import StockDetail from "./stockDetail/StockDetail";
import "./Home.css";

const Home = () => {
  const [theme, setTheme] = useState("light");
  const [showLoginPopup, setShowLoginPopup] = useState(false);
  const [showRegisterPopup, setShowRegisterPopup] = useState(false);
  const [user, setUser] = useState(null); // Store the full user object
  const [selectedStock, setSelectedStock] = useState(null);

  useEffect(() => {
    // Load user from localStorage on initial render
    const savedUser = localStorage.getItem("user");
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  useEffect(() => {
    document.body.className = theme;
  }, [theme]);

  const handleThemeChange = (mode) => {
    setTheme(mode);
  };

  const handleSuccessfulLogin = (userObject) => {
    // Save the full user object in state and localStorage
    setUser(userObject);
    console.log(userObject);
    localStorage.setItem("user", JSON.stringify(userObject));
    
    setShowLoginPopup(false);
  };

  const handleLogout = () => {
    localStorage.removeItem("user");
    setUser(null); // Clear user object on logout
    setSelectedStock(null);
  };

  const handleStockClick = (stock) => {
    setSelectedStock(stock);
   
  };

  const handleBack = () => {
    setSelectedStock(null); // Clear the selected stock
  };

  const refreshWatchlist = () => {
    setSelectedStock(null); // Deselect any stock to force the refresh of the sidebar
  };

  return (
    <div className={`home-page ${theme}`}>
      <Header onThemeChange={handleThemeChange} onLogout={handleLogout} />
      <div className="home-container">
        <Sidebar user={user} onStockClick={handleStockClick} refreshWatchlist={refreshWatchlist} />

        {/* Conditionally render content */}
        {selectedStock ? (
          <StockDetail stock={selectedStock} theme={theme} onBack={handleBack} refreshWatchlist={refreshWatchlist} />
        ) : (
          <div className="welcome-container">
            {user ? (
              <h1>Your Dashboard</h1>
            ) : (
              <>
                <h1>Welcome to INves Stock Dashboard!</h1>
                <div className="button-container">
                  <button
                    className="auth-button login-button"
                    onClick={() => setShowLoginPopup(true)}
                  >
                    Log In
                  </button>
                  <button
                    className="auth-button register-button"
                    onClick={() => setShowRegisterPopup(true)}
                  >
                    Register
                  </button>
                </div>
              </>
            )}
          </div>
        )}
      </div>

      {showLoginPopup && (
        <LoginPopup
          closePopup={() => setShowLoginPopup(false)}
          onLoginSuccess={handleSuccessfulLogin}
        />
      )}
      {showRegisterPopup && (
        <RegisterPopup closePopup={() => setShowRegisterPopup(false)} />
      )}
    </div>
  );
};

export default Home;
