import React, { createContext, useState, useContext, useEffect } from "react";
import { User } from "../models/User"; // Import your User class

// Create a context for user data
const UserContext = createContext();

// Create a provider component to wrap the app
export const UserProvider = ({ children }) => {
  // Initialize user state from localStorage
  const [user, setUser] = useState(() => {
    try {
      const storedUser = localStorage.getItem("user");
      if (storedUser) {
        const parsedUser = JSON.parse(storedUser);
        return new User(
          parsedUser.id,
          parsedUser.title,
          parsedUser.firstName,
          parsedUser.lastName,
          parsedUser.username,
          parsedUser.password,
          parsedUser.address,
          parsedUser.phone,
          parsedUser.email,
          parsedUser.iban
        );
      }
    } catch (error) {
      console.error("Failed to parse user data from localStorage:", error);
    }
    return null;
  });

  // Sync user data with localStorage whenever it changes
  useEffect(() => {
    if (user) {
      localStorage.setItem("user", JSON.stringify(user));
    } else {
      localStorage.removeItem("user");
    }
  }, [user]);

  // Function to set user info
  const setUserInfo = (userInfo) => {
    const newUser = new User(
          userInfo.id,
          userInfo.title,
          userInfo.firstName,
          userInfo.lastName,
          userInfo.username,
          userInfo.password,
          userInfo.address,
          userInfo.phone,
          userInfo.email,
          userInfo.iban
    );
    setUser(newUser);
  };

  // Function to clear user info
  const clearUser = () => {
    setUser(null);
  };

  return (
    <UserContext.Provider value={{ user, setUserInfo, clearUser }}>
      {children}
    </UserContext.Provider>
  );
};

// Custom hook to use the UserContext
export const useUser = () => {
  return useContext(UserContext);
};
